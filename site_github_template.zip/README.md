# Site Web Template

## Déploiement avec GitHub Pages

1. Créer un repo GitHub
2. Uploader tous les fichiers
3. Aller dans Settings > Pages
4. Choisir branche main
5. Ton site sera en ligne

